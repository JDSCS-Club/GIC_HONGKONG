#!/bin/bash

cd /mnt/blkmnt/run/bin
pid=`cat rundump | grep "\[V4L Update Display\]: left=0, top=0, width=1920, height=1080" `

if [ -z "$pid" ]; then
    echo "ERROR NOT RUNNING GST " >> /mnt/blkmnt/log/log.txt
    sync
    ./reset.sh
else
    echo OK RUNNING 
fi
