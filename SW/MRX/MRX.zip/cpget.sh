#!/bin/bash

rm client
rm mrxplayer
rm light2pwm
rm netchecker
rm mrx_bootins
rm mtx_checker0
rm mtx_checker1
rm presender

cp ../../client/client .
cp ../../mrxplayer/mrxplayer .
cp ../../light2pwm/light2pwm .
cp ../../netchecker_tcp/netchecker .
cp ../../mrx_bootins/mtx_bootins .
cp ../../mtxchecker/mtx_checker ./mtx_checker0
cp ../../mtxchecker/mtx_checker ./mtx_checker1
cp ../../presender .
