#!/bin/bash

/mnt/blkmnt/run/bin/rmk.sh

rm /mnt/blkmnt/zip/*
cd /mnt/blkmnt/zip

if [ $1 = 0 ]; then
    echo DM1
    wget ftp://zeus:zeus@192.168.10.8/zip/MRX.zip
    wget ftp://zeus:zeus@192.168.10.8/zip/MRX.cksum
else
    echo DM2
    wget ftp://zeus:zeus@192.168.90.8/zip/MRX.zip
    wget ftp://zeus:zeus@192.168.90.8/zip/MRX.cksum
fi

echo 1 > /mnt/blkmnt/run/bin/sys/debugmsg
echo 1 > /var/mrx_apploader/sys/debugmsg

kill -9 `ps | grep lrun.sh | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "var/loader" | grep -v grep | awk '{print $1}'`
sync
halt
sleep 5

echo 4 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio4/direction
echo 1 > /sys/class/gpio/gpio4/value
sleep 1
echo 0 > /sys/class/gpio/gpio4/value
sleep 1
reboot
