#!/bin/bash

while [ 1 ]
   do
        pid=`ps | grep "mrx_aploader" | grep -v 'grep' | awk '{print $1}'`
        if [ -z $pid ]; then
            ./rmk.sh 
            ./mrx_aploader 0 &
        fi
        sleep 5
    done
