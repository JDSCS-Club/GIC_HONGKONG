#!/bin/bash

cd /mnt/blkmnt/run/bin
pid=`echo $LD_LIBRARY_PATH | grep bin`
if [ -z $pid ]; then
    echo ZERO
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/mnt/blkmnt/run/bin
else
    echo non-ZERO
fi

killall mrxplayer

if [ -z "$1" ]; then
    portnumber=5000
else
    portnumber=$1
fi

if [ $(./pgrep -f "video_run.sh" | wc -l) -gt 2 ]; then
    echo OVER
    exit
fi

dfilename2=$"/sys/class/net/eth0/operstate"

#under-traffic
counter=0

pid=`ps | grep "traffic_checker.sh" | grep -v 'grep' | awk '{print $1}'`
if [ -z $pid ]; then
    /mnt/blkmnt/run/bin/traffic_checker.sh &
fi

kill -9 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`

#./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 4 TEST ./mtr.png &
#sleep 1

killall mrxplayer
#kill -2 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
#kill -2 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
#kill -2 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
#kill -9 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
#kill -9 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
#kill -9 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`

./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0 TEST ./mtr.png &
pid3=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v 'grep' | awk '{print $1}'`

while [ -z $pid3 ]
do
    pid3=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v 'grep' | awk '{print $1}'`
    sleep 1
    counter=$((counter+1))
    if [[ "$counter" -gt 3 ]]; then
        ./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0 TEST ./mtr.png &
        sleep 6
    elif [[ "$counter" -gt 6 ]]; then
        counter=10
    fi
done

counter=0
while [ 1 ]
do
    cknet=`cat $dfilename2`
    pid0=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 4" | grep -v 'grep' | awk '{print $1}'`
    pid1=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v 'grep' | awk '{print $1}'`

    echo 3 > ./sys/playstatus

    if [ $cknet == "up" ]; then

        pid0=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 4" | grep -v 'grep' | awk '{print $1}'`
        if [ -z $pid0 ]; then
            # nothing do
            echo ""
        else
            kill -2 $pid0
            kill -2 $pid0
            sleep 2
            kill -9 $pid0
            sleep 2
        fi

        pid1=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v 'grep' | awk '{print $1}'`
        if [ -z $pid1 ]; then
            ./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0 TEST ./mtr.png &
            sleep 5
        fi

        while [ $(./pgrep -f "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | wc -l) -gt 1 ]
        do
            kill -2 `ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v grep | awk '{print $1}'`
            sleep 3
        done

        # kbit ckecher
        val1=`/mnt/blkmnt/run/bin/vnstat -tr | grep "rx" | awk '{print $3}'`
        if [ $val1 == "kbit/s" ]; then
            val0=`/mnt/blkmnt/run/bin/vnstat -tr | grep "rx" | awk '{print $2}' | sed 's/\./ /g' | awk '{print $1}'`

            # under traffic 100kbit/s action counter
            if [ "$val0" -lt 100 ]; then
                counter=$((counter+1))
                echo LOW
            fi
        else
            counter=0
        fi

        # kbit ckecher
        if [ $val1 == "kbit/s" ]; then

            #
            # kbps Connection
            #

            # over counter kbit/s
            if [[ "$counter" -gt 2 ]]; then

                #
                # infomation MRT
                #
                kill -2 `ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v grep | awk '{print $1}'`
                kill -2 `ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v grep | awk '{print $1}'`
                kill -2 `ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v grep | awk '{print $1}'`
                kill -9 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
                sleep 1

                ./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 4 TEST ./mtr.png &
                sleep 5

                pid2=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 4" | grep -v 'grep' | awk '{print $1}'`
                counter=0

                while [ -z $pid2 ]
                do
                    pid2=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 4" | grep -v 'grep' | awk '{print $1}'`
                    sleep 1
                    counter=$((counter+1))
                    if [[ "$counter" -gt 3 ]]; then
                        ./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 4 TEST ./mtr.png &
                        sleep 6
                    elif [[ "$counter" -gt 6 ]]; then
                        counter=10
                    fi
                    # status0 => notworking mrxplayer
                    echo 0 > ./sys/playstatus
                done

                #
                # PLAYER Enable
                #
                kill -2 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
                kill -2 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
                kill -2 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
                kill -2 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
                kill -9 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
                ./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0 TEST ./mtr.png &
                sleep 2
                pid3=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v 'grep' | awk '{print $1}'`
                counter=0

                while [ -z $pid3 ]
                do
                    pid3=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v 'grep' | awk '{print $1}'`
                    sleep 1
                    counter=$((counter+1))
                    if [[ "$counter" -gt 3 ]]; then
                        ./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0 TEST ./mtr.png &
                        sleep 6
                    elif [[ "$counter" -gt 6 ]]; then
                        counter=10
                    fi
                    # status1 => notworking mrxplayer
                    echo 1 > ./sys/playstatus
                done

                #
                # wait Running PLAYER
                #
                val2=`/mnt/blkmnt/run/bin/vnstat -tr | grep "rx" | awk '{print $3}'`
                while [ $val2 == "kbit/s" ]
                do
                    cknet=`cat $dfilename2`
                    val2=`/mnt/blkmnt/run/bin/vnstat -tr | grep "rx" | awk '{print $3}'`

                    # not connect ethernet
                    if [ $cknet == "down" ]; then
                        val2=0
                    fi

                    pid3=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v 'grep' | awk '{print $1}'`
                    if [ -z $pid3 ]; then
                        ./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0 TEST ./mtr.png &
                        sleep 5
                    fi
                    echo 2 > ./sys/playstatus
                    echo "WAIT broadcast" >> /mnt/blkmnt/log/log.txt
                    sleep 1
                done

            fi

        else

            #
            # Mbps Connection
            # Normal status
            #

            # kill player
            counter=0
            pid0=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 4" | grep -v 'grep' | awk '{print $1}'`
            if [ -z $pid0 ]; then
                # nothing do
                echo ""
            else
                kill -2 $pid0
                sleep 2
                kill -9 $pid0
                sleep 2
            fi

            pid1=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v 'grep' | awk '{print $1}'`
            if [ -z $pid1 ]; then
                ./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0 TEST ./mtr.png &
                sleep 5
            fi
        fi

    else

        #
        # Down Connection
        #

        pid1=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 0" | grep -v 'grep' | awk '{print $1}'`
        if [ -z $pid1 ]; then
            # nothing do
            echo ""
        else
            kill -2 $pid1
            kill -2 $pid1
            kill -2 $pid1
            kill -2 $pid1
            kill -9 $pid1
        fi

        pid0=`ps | grep "./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 4" | grep -v 'grep' | awk '{print $1}'`
        if [ -z $pid0 ]; then
            ./mrxplayer 0 $portnumber 224.1.1.2 /dev/video16 4 TEST ./mtr.png &
            sleep 5
        fi

        echo 4 > ./sys/playstatus
    fi

    sleep 1
done
