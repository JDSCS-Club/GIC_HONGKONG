#!/bin/bash

dfilename0=$"/var/del.sh"
if [ -f $dfilename0 ]; then
    echo $dfilename0
    rm -rf /var/del.sh
    sync
fi

sync
ck=`cksum /var/loader | awk '{print $1}'`
gck=3009974107
chmod +x /mnt/blkmnt/run/bin/loader

# current version OK/FAIL
if [ $ck = $gck ]
then
    cdiff=1 
else
    cdiff=0
    rm /var/loader
    sync
    dfilename0=$"/mnt/blkmnt/run/bin/loader"
    if [ -f $dfilename0 ]; then
        echo "copyfile"
        chmod +x /mnt/blkmnt/run/bin/loader
        cp /mnt/blkmnt/run/bin/loader /var/
        sync
    fi 
fi
echo $cdiff

sleep 60
ck=`cksum /var/mrx_apploader/mrx_aploader | awk '{print $1}'`
gck=2768324640

# current version OK/FAIL
if [ $ck = $gck ]
then
    cdiff=1 
else
    cdiff=0
    rm /var/mrx_apploader_nolist.tar.gz
    rm /var/mrx_apploader.ptu
    rm /var/mrx_apploader.cksum
    sync
    /mnt/blkmnt/run/bin/ncftpget -u zeus -p zeus 192.168.10.8 /var/  ./zip/mrx_apploader.ptu
    /mnt/blkmnt/run/bin/ncftpget -u zeus -p zeus 192.168.10.8 /var/  ./zip/mrx_apploader.cksum

    dfilename0=$"/var/mrx_apploader.ptu"
    dfilename1=$"/var/mrx_apploader.cksum"

    if [ -f $dfilename0 ]; then 
        ck=`cksum $dfilename0 | awk '{print $1}'`
        gck=`head -1 $dfilename1 | awk '{print $1}'`
    else
        ck=1
        gck=2
    fi

    if [ $ck = $gck ]; then
        echo $dfilename0
        cd /var
        tar xvzf mrx_apploader.ptu
        chmod 777 /var/mrx_apploader/*
        sync
    fi 
fi
echo $cdiff

