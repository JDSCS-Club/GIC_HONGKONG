#!/bin/bash

dfilename0=$"/mnt/blkmnt/run/bin/sys/traffic_val0"
dfilename1=$"/mnt/blkmnt/run/bin/sys/traffic_val1"
dfilename2=$"/mnt/blkmnt/log/messages"
dfilename3=$"/mnt/blkmnt/log/log.txt"

cd /mnt/blkmnt/run/bin

pid=`echo $LD_LIBRARY_PATH | grep bin`                     
if [ -z $pid ]; then                  
    echo ZERO                         
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/mnt/blkmnt/run/bin
else                                                           
    echo non-ZERO                                          
fi

if [ $(./pgrep -f "traffic_checker.sh" | wc -l) -gt 2 ]; then
exit
fi

echo 1  > $dfilename1
echo 10 > $dfilename0

while [ 1 ]
do

    val1=`/mnt/blkmnt/run/bin/vnstat -tr | grep "rx" | awk '{print $3}'`
    val0=`/mnt/blkmnt/run/bin/vnstat -tr | grep "rx" | awk '{print $2}'`
    val2=`cat $dfilename2 | grep Oops`

    echo $val0 > $dfilename0

    if [ $val1 == "kbit/s" ]; then
        echo 0 > $dfilename1
    else
        echo 1 > $dfilename1
    fi

    if [ -z "$val2" ]; then
        echo none
    else
        echo get
        sed -e "s/Oops/Accept/g" $dfilename2 > messages_dump                                  
        echo $val2 > $dfilename3
        cp messages_dump > $dfilename2
        ./rma.sh
        sync
    fi
    sleep 25

done
