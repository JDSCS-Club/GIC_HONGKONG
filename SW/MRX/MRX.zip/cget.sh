rm client
rm mrxplayer
rm light2pwm
rm netchecker
rm mrx_bootins
rm mtx_checker0
rm mtx_checker1
rm presender
wget http://192.168.0.155/netchecker
wget http://192.168.0.155/mrxplayer
wget http://192.168.0.155/client
wget http://192.168.0.155/light2pwm
wget http://192.168.0.155/mrx_bootins
wget http://192.168.0.155/mtx_checker0
wget http://192.168.0.155/mtx_checker1
wget http://192.168.0.155/presender
chmod +x client
chmod +x netchecker
chmod +x light2pwm
chmod +x mrxplayer
chmod +x mrx_bootins
chmod +x mtx_checker0
chmod +x mtx_checker1
chmod +x presender
