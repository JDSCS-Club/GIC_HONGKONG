rm /usr/lib/gstreamer-0.10/libgstmcast.so.1.0
rm /usr/lib/gstreamer-0.10/libgstcamplay.so.1.0
rm /usr/lib/gstreamer-0.10/libgstmrxcast.so.1.0
wget http://10.0.0.183/libgstmcast.so.1.0
wget http://10.0.0.183/libgstcamplay.so.1.0
wget http://10.0.0.183/libgstmrxcast.so.1.0
mv libgstmcast.so.1.0 /usr/lib/gstreamer-0.10/libgstmcast.so.1.0
mv libgstcamplay.so.1.0 /usr/lib/gstreamer-0.10/libgstcamplay.so.1.0
mv libgstmrxcast.so.1.0 /usr/lib/gstreamer-0.10/libgstmrxcast.so.1.0
