#!/bin/bash

cd /mnt/blkmnt/run/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/mnt/blkmnt/run/bin

dfilename0=$"/usr/lib/libpcap.so.0.8"
if [ -f $dfilename0 ]; then
    echo $dfilename0
else
    echo Noting
    cp ./libpcap.so.0.8   /usr/lib/libpcap.so.0.8
    cp ./libpcap.so.1.1.1 /usr/lib/libpcap.so.1.1.1
fi

#cd /var/mrx_apploader
rm /mnt/blkmnt/run/bin/dumplldp

chmod +x tcpdump

ip3=`ifconfig eth0 | grep "inet addr" | sed 's/addr\://g' | awk '{print $2}' | sed 's/\./ /g' | awk '{print $3}'`
ip4=`ifconfig eth0 | grep "inet addr" | sed 's/addr\://g' | awk '{print $2}' | sed 's/\./ /g' | awk '{print $4}'`

cip3=$ip3
cip4=$ip4

hchflag=0
lchflag=0

echo 0 > dumplldp
./tcpdump -i eth0 -s 1500 -XX -c 1 'ether proto 0x88cc' > dumplldp

getport=`cat dumplldp | grep "0020" | awk '{print $5}'`
echo "getting port value : "$getport

#LOWER IP ADDRESS
if [ "$getport" == "2333" ]
then
    cip4="42"
    lchflag=1
fi

if [ "$getport" == "2334" ]
then
    cip4="43"
    lchflag=1
fi

echo "PortSet "$lchflag

#NSW-PORT
if [ "$lchflag" == "0" ]
then
    cip4="35"
    echo 0 > dumplldp
    ./tcpdump -i eth0 -s 1500 -vv -c 1 'ether proto 0x88cc' > dumplldp

    getipnsw=`cat dumplldp | grep "Port" | awk '{print $7}'`
    echo "getting port value : "$getipnsw

    if [ "$getipnsw" == "port5" ]
    then
        cip4="35"
    fi

    getipnsw=`cat dumplldp | grep "Management Address length" | awk '{print $8}'`
    echo "getting ip value : "$getipnsw

    if [ "$getipnsw" == "192.168.41.9" ]
    then
        cip3="41"
        lchflag=2
    fi

    if [ "$getipnsw" == "192.168.42.9" ]
    then
        cip3="42"
        lchflag=2
    fi

fi

#UPPER IP ADDRESS
getip=`cat dumplldp | grep "00a0" | awk '{print $2}'`
echo "getting ip value : "$getip

#13
if [ "$getip" == "a80d" ]
then
    cip3="13"
    hchflag=1
fi

#14
if [ "$getip" == "a80e" ]
then
    cip3="14"
    hchflag=1
fi

#23
if [ "$getip" == "a817" ]
then
    cip3="23"
    hchflag=1
fi

#24
if [ "$getip" == "a818" ]
then
    cip3="24"
    hchflag=1
fi

#33
if [ "$getip" == "a821" ]
then
    cip3="33"
    hchflag=1
fi

#34
if [ "$getip" == "a822" ]
then
    cip3="34"
    hchflag=1
fi

#43
if [ "$getip" == "a82b" ]
then
    cip3="43"
    hchflag=1
fi

#44
if [ "$getip" == "a82c" ]
then
    cip3="44"
    hchflag=1
fi

#53
if [ "$getip" == "a835" ]
then
    cip3="53"
    hchflag=1
fi

#54
if [ "$getip" == "a836" ]
then
    cip3="54"
    hchflag=1
fi

#63
if [ "$getip" == "a83f" ]
then
    cip3="63"
    hchflag=1
fi

#64
if [ "$getip" == "a840" ]
then
    cip3="64"
    hchflag=1
fi

#73
if [ "$getip" == "a849" ]
then
    cip3="73"
    hchflag=1
fi

#74
if [ "$getip" == "a84a" ]
then
    cip3="74"
    hchflag=1
fi

#83
if [ "$getip" == "a853" ]
then
    cip3="83"
    hchflag=1
fi

#84
if [ "$getip" == "a854" ]
then
    cip3="84"
    hchflag=1
fi

#93
if [ "$getip" == "a85d" ]
then
    cip3="93"
    hchflag=1
fi

#94
if [ "$getip" == "a85e" ]
then
    cip3="94"
    hchflag=1
fi


CIP=$ip3"."$ip4
RIP=$cip3"."$cip4

echo "ChangeIPAddress : "$RIP" : "$hchflag

if [ "$lchflag" == "1" ] || [ "$hchflag" == "1" ] || [ "$lchflag" == "2" ] 
then
    echo changeip
    sed -e "s/"$CIP"/"$RIP"/g" /etc/rc.d/rc.conf > test.txt.tmp
    sync

    if [ "$CIP" == "$RIP" ] 
    then
        echo not-reset 
    else
        sync
        #cp test.txt.tmp /etc/rc.d/rc.conf
        sync
        export SYSCFG_IFACE0=y
        export INTERFACE0="eth0"
        export IPADDR0="192.168."$RIP
        export NETMASK0="255.255.0.0"
        export BROADCAST0="192.168.0.255"
        export GATEWAY0="192.168.0.1"
        export NAMESERVER0="168.126.63.1"
        /mnt/blkmnt/run/bin/rmk.sh
        sync
        /etc/rc.d/init.d/network restart &
        #/mnt/blkmnt/run/bin/reset.sh
    fi
else
    echo not-change 
fi

rm /mnt/blkmnt/run/bin/dumplldp
sync
