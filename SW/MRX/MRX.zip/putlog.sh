#!/bin/bash

ip=`ifconfig eth0 | grep "inet addr" | sed 's/addr\://g' | awk '{print $2}'` 

cd /mnt/blkmnt/log/
rm "*.log.tar.gz"
tar cvzf $ip".log.tar.gz" /mnt/blkmnt/log
sleep 360
/mnt/blkmnt/run/bin/ncftpput -u zeus -p zeus 192.168.10.8 log $ip".log.tar.gz"
/mnt/blkmnt/run/bin/ncftpput -u zeus -p zeus 192.168.90.8 log $ip".log.tar.gz"
