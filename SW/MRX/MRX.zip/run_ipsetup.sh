#!/bin/bash

cd /mnt/blkmnt/run/bin
while [ 1 ]
do
    ./ipsetup.sh 
    sleep 180
done
