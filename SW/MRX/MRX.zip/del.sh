#!/bin/bash
cd /mnt/blkmnt/log/
sed -e '1,100d' /mnt/blkmnt/log/log.txt > /mnt/blkmnt/log/log1.log
mv /mnt/blkmnt/log/log1.log /mnt/blkmnt/log/log.txt
sed -e '1,100d' /mnt/blkmnt/log/log_pro.txt > /mnt/blkmnt/log/log1.log
mv /mnt/blkmnt/log/log1.log /mnt/blkmnt/log/log_pro.txt
sync
