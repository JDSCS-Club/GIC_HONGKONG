#!/bin/bash
cd /mnt/blkmnt/run/bin

pid=`ps | grep "mrx_bootins" | grep -v 'grep' | wc -l | awk '{print $1}'`
while [ $pid -gt 0 ]
do
        kill -2 `ps | grep mrx_bootins | grep -v grep | awk '{print $1}'`
        kill -9 `ps | grep mrx_bootins | grep -v grep | awk '{print $1}'`
        pid=`ps | grep "mrx_bootins" | grep -v 'grep' | wc -l | awk '{print $1}'`
done
kill -2 `ps | grep video_run.sh | grep -v grep | awk '{print $1}'` 
kill -9 `ps | grep video_run.sh | grep -v grep | awk '{print $1}'` 


pid=`ps | grep "mrx_test" | grep -v 'grep' | awk '{print $1}'`
if [ -z $pid ]; then
    ./mrx_test &
fi
