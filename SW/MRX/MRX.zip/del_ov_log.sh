#!/bin/bash

dfilename0=$"/mnt/blkmnt/log/log.txt"

if [ -f $dfilename0 ]; then
    sz=$(ls -l $dfilename0 | awk '{print $5}')
    echo $dfilename0 - $sz
	while [ $sz -gt 4000000 ];
	do
        sz=$(ls -l $dfilename0 | awk '{print $5}')
        echo $dfilename0 - $sz
		sed -e '1,20000d'  $dfilename0 > /root/back.log
		cp /root/back.log $dfilename0
		rm /root/back.log
		sync
	done
else
    echo start_zero > $dfilename0
fi
