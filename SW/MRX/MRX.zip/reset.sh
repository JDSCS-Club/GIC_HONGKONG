#!/bin/bash

kill -9 `ps | grep "run.sh" | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "/var/mrx_apploader/run.sh" | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "runA.sh" | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "putlog.sh" | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "run_ipsetup.sh" | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "/sbin/syslogd" | grep -v grep | awk '{print $1}'`

/mnt/blkmnt/run/bin/kill.sh 
/mnt/blkmnt/run/bin/rmk.sh 
sync

ip3=`ifconfig eth0 | grep "inet addr" | sed 's/addr\://g' | awk '{print $2}' | sed 's/\./ /g' | awk '{print $3}'`
ip4=`ifconfig eth0 | grep "inet addr" | sed 's/addr\://g' | awk '{print $2}' | sed 's/\./ /g' | awk '{print $4}'`
RIP=$ip3"."$ip4

cd /mnt/blkmnt/run/bin
rm ./test.txt.tmp

echo changeip
sed -e "s/"13.42"/"$RIP"/g" ori_rc.conf > test.txt.tmp
cp test.txt.tmp /etc/rc.d/rc.conf
sync

echo 0 > /sys/class/leds/backon_led/brightness
sync
kill -9 `ps | grep lrun.sh | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "var/loader" | grep -v grep | awk '{print $1}'`
sleep 2
cd /mnt
sync
sleep 120
sync

echo 4 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio4/direction
echo 1 > /sys/class/gpio/gpio4/value
sleep 1
echo 0 > /sys/class/gpio/gpio4/value
sleep 1
reboot
umount -a
