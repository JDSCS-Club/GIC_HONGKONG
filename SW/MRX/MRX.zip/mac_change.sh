#!/bin/bash

macadd=`ifconfig eth0 | grep "eth0" |  awk '{print $5}'`
sed -e "s/18:30:09:00:00:63/"$1"/g" ./network > test.txt.tmp
cp test.txt.tmp /etc/rc.d/init.d/network 
chmod +x /etc/rc.d/init.d/network
sync

export SYSCFG_IFACE0=y
export INTERFACE0="eth0"
export IPADDR0=$2
export NETMASK0="255.255.0.0"
export BROADCAST0="192.168.0.255"
export GATEWAY0="192.168.0.1"
export NAMESERVER0="168.126.63.1"

echo "192.168.10.8/zip" > list
echo "/mnt/blkmnt/zip" >> list
echo "/mnt/blkmnt/run/bin" >> list
echo "MRX.zip" >> list
echo "MRX.cksum" >> list
echo "zeus" >> list
echo "zeus" >> list
echo $3 >> list
cp list /var/mrx_apploader/list

sync
/etc/rc.d/init.d/network restart 

macadd=`ifconfig eth0 | grep "eth0" |  awk '{print $5}'`

if [ "$macadd" == "$1" ]
then
    echo "PASS"
else
    echo "FAIL"
fi
