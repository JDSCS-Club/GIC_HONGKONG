#!/bin/bash

dfilename0=$"/root/mrx_apploader.ptu"
dfilename1=$"/root/mrx_apploader.cksum"

dfilename2=$"/root/uImage_mrx"
dfilename3=$"/root/uImage_mrx.cksum"

dfilename4=$"/root/MRX.zip"
dfilename5=$"/root/MRX.cksum"


echo ptucall > "/root/"$1".log"
cd /root
/root/tftp -l $1".log" -p $2

chmod +x /root/kill_mrx.sh
/root/kill_mrx.sh 

#chmod +x /root/mmc3
#/root/mmc3 writeprotect user set temp 0 24576 /dev/mmcblk0

if [ -f $dfilename0 ]; then
    cd /root
    ck=`cksum ./mrx_apploader.ptu | awk '{print $1}'`
else
    ck=1
fi

if [ -f $dfilename1 ]; then
    cd /root
    gck=`head -1 ./mrx_apploader.cksum | awk '{print $1}'`
else
    gck=2
fi


if [ $ck = $gck ]
then
    cd /var
    cp /root/mrx_apploader.ptu .
    tar xvzf mrx_apploader.ptu
    cd /var/mrx_apploader
    chmod +x *
    echo ptucall > /root/$1.log
else
    echo ptuckerr > /root/$1.log
    cd /root
    /root/tftp -l $1".log" -p $2
    exit 1
fi


if [ -f $dfilename2 ]; then
    cd /root
    ck=`cksum ./uImage_mrx | awk '{print $1}'`
else
    ck=1
fi

if [ -f $dfilename3 ]; then
    cd /root
    gck=`head -1 ./uImage_mrx.cksum | awk '{print $1}'`
else
    gck=2
fi


if [ $ck = $gck ]
then
    cd /root
    dd if=uImage_mrx of=/dev/mmcblk0 bs=512 seek=2048 conv=fsync
    echo ptucall_ker > /root/$1.log
else
    echo ptuckerr_ker > /root/$1.log
    cd /root
    exit 1
fi


if [ -f $dfilename3 ]; then
    cd /root
    ck=`cksum ./MRX.zip | awk '{print $1}'`
else
    ck=1
fi

if [ -f $dfilename4 ]; then
    cd /root
    gck=`head -1 ./MRX.cksum | awk '{print $1}'`
else
    gck=2
fi


if [ $ck = $gck ]
then
    cd /root
    mount /dev/mmcblk0p2 /mnt/blkmnt/
    cp /root/MRX.zip /mnt/blkmnt/zip/
    cp /root/MRX.cksum /mnt/blkmnt/zip/
    sync
    echo ptucall_mrx > /root/$1.log
else
    echo ptuckerr_mrx > /root/$1.log
    cd /root
fi


cd /root
/root/tftp -l $1".log" -p $2
sync
