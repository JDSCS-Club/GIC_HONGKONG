#!/bin/bash

while [ 1 ]
do
    cd  /mnt/blkmnt/log
    pid=`cat /mnt/blkmnt/log/messages | grep "Internal error: Oops" `

    if [ -z "$pid" ]; then
        echo "ERROR Kernel oops " >> /mnt/blkmnt/log/log.txt
        echo OK RUNNING 
    else
        cp /mnt/blkmnt/log/messages /mnt/blkmnt/log/messages_dead
        sync
        cd  /mnt/blkmnt/run/bin
        /mnt/blkmnt/run/bin/reset.sh
    fi
    sleep 5
done
