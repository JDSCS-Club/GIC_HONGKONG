#!/bin/bash
cd /mnt/blkmnt/run/bin

pid=`echo $LD_LIBRARY_PATH | grep bin`                                      
if [ -z $pid ]; then
    echo ZERO
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/mnt/blkmnt/run/bin
else
    echo non-ZERO
fi

pid=`ps | grep "mrx_test" | grep -v 'grep' | wc -l | awk '{print $1}'`
while [ $pid -gt 0 ]
do
    kill -2 `ps | grep mrx_test | grep -v grep | awk '{print $1}'`
    kill -9 `ps | grep mrx_test | grep -v grep | awk '{print $1}'`
    pid=`ps | grep "mrx_test" | grep -v 'grep' | wc -l | awk '{print $1}'`
done

pid=`ps | grep "mrx_bootins" | grep -v 'grep' | awk '{print $1}'`
if [ -z $pid ]; then
    ./mrx_bootins &
fi
sleep 2

while [ $(./pgrep -f "mrx_bootins" | wc -l) -gt 2 ] 
do
        kill -2 `ps | grep mrx_bootins | grep -v grep | awk '{print $1}'`
        kill -9 `ps | grep mrx_bootins | grep -v grep | awk '{print $1}'`
        sleep 1
done

#while [ $(./pgrep -f "video_run.sh" | wc -l) -gt 1 ] 
#do
#kill -2 `ps | grep "video_run.sh" | grep -v grep | awk '{print $1}'`
#kill -9 `ps | grep "video_run.sh" | grep -v grep | awk '{print $1}'`
#sleep 1
#done
