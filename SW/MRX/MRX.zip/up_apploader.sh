#!/bin/bash

dfilename0=$"/var/del.sh"
if [ -f $dfilename0 ]; then
    echo $dfilename0
    rm -rf /var/del.sh
    sync
fi

sync
ck=`cksum /var/loader | awk '{print $1}'`
gck=`cksum /mnt/blkmnt/run/bin/loader | awk '{print $1}'`
chmod +x /mnt/blkmnt/run/bin/loader

# current version OK/FAIL
if [ $ck = $gck ]
then
    cdiff=1 
else
    cdiff=0
    rm /var/loader
    sync
    dfilename0=$"/mnt/blkmnt/run/bin/loader"
    if [ -f $dfilename0 ]; then
        echo "copyfile"
        chmod +x /mnt/blkmnt/run/bin/loader
        cp /mnt/blkmnt/run/bin/loader /var/
        sync
    fi 
fi
echo $cdiff

