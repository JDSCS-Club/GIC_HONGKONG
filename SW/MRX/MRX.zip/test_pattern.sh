#!/bin/bash
cd /mnt/blkmnt/run/bin

kill -2 `ps | grep mrx_bootins | grep -v grep | awk '{print $1}'` 
kill -2 `ps | grep mrx_test | grep -v grep | awk '{print $1}'`
kill -2 `ps | grep client | grep -v grep | awk '{print $1}'`
kill -2 `ps | grep video_run.sh | grep -v grep | awk '{print $1}'` 
kill -9 `ps | grep mrx_bootins | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep mrx_test | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep client | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep client | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep video_run.sh | grep -v grep | awk '{print $1}'` 

kill -2 `ps | grep "mrxplayer 0 5000 224.1.1.2 /dev/video16 4" | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "mrxplayer 0 5000 224.1.1.2 /dev/video16 4" | grep -v grep | awk '{print $1}'`
kill -2 `ps | grep "mrxplayer 0 5000 224.1.1.2 /dev/video16 3" | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "mrxplayer 0 5000 224.1.1.2 /dev/video16 3" | grep -v grep | awk '{print $1}'`
kill -2 `ps | grep "mrxplayer 0 5000 224.1.1.2 /dev/video16 2" | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "mrxplayer 0 5000 224.1.1.2 /dev/video16 2" | grep -v grep | awk '{print $1}'`
kill -2 `ps | grep "mrxplayer 0 5000 224.1.1.2 /dev/video16 1" | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "mrxplayer 0 5000 224.1.1.2 /dev/video16 1" | grep -v grep | awk '{print $1}'`
kill -2 `ps | grep "mrxplayer 0 5000 224.1.1.2 /dev/video16 0" | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep "mrxplayer 0 5000 224.1.1.2 /dev/video16 0" | grep -v grep | awk '{print $1}'`

pid=`ps | grep "gst-launch-0.10 videotestsrc" | grep -v 'grep' | awk '{print $1}'`
if [ -z $pid ]; then
    gst-launch videotestsrc pattern=$1 ! mfw_v4lsink device=/dev/video16 &
fi
