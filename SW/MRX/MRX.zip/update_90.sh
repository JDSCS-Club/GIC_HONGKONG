#!/bin/bash
rm /mnt/blkmnt/zip/*
cd /mnt/blkmnt/zip/
wget ftp://zeus:zeus@192.168.90.8/zip/MRX.zip
wget ftp://zeus:zeus@192.168.90.8/zip/MRX.cksum
echo 1 > /mnt/blkmnt/run/bin/sys/debugmsg
sync

/mnt/blkmnt/run/bin/kill.sh
/mnt/blkmnt/run/bin/kill_mrx.sh

sleep 3
unzip -o /mnt/blkmnt/zip/MRX.zip -d  /mnt/blkmnt/run/bin

/mnt/blkmnt/run/bin/reset.sh
