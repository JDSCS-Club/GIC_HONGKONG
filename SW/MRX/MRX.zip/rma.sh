#!/bin/bash

kill -9 `ps | grep crun.sh | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep nrun.sh | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep test_run.sh | grep -v grep | awk '{print $1}'`
kill -2 `ps | grep mrx_bootins | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep mrx_bootins | grep -v grep | awk '{print $1}'`
kill -2 `ps | grep mrx_test | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep mrx_test | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep client | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep mrxplayer | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep netchecker | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep server | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep mtx1 | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep mtx2 | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep mtx3 | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep sender | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep play | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep caplisten | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep light2pwm | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep mtx_checker | grep -v grep | awk '{print $1}'`
kill -2 `ps | grep mtx_checker0 | grep -v grep | awk '{print $1}'`
kill -2 `ps | grep mtx_checker1 | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep mtx_checker0 | grep -v grep | awk '{print $1}'`
kill -9 `ps | grep mtx_checker1 | grep -v grep | awk '{print $1}'`
