#!/bin/bash
echo 1 > ./sys/debugmsg
rm /mnt/blkmnt/zip/*
cd /mnt/blkmnt/zip/
wget ftp://zeus:zeus@$1/zip/MRX.zip
wget ftp://zeus:zeus@$1/zip/MRX.cksum
sync
echo 4 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio4/direction
echo 1 > /sys/class/gpio/gpio4/value
sleep 1
echo 0 > /sys/class/gpio/gpio4/value
sleep 1
reboot
