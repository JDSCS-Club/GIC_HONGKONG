#!/bin/bash

dfilename0=$"/mnt/blkmnt/run/bin/sys/NetStatus"
dfilename1=$"/mnt/blkmnt/run/bin/sys/oNetStatus"


cd /mnt/blkmnt/run/bin
pid=`echo $LD_LIBRARY_PATH | grep bin`                     
if [ -z $pid ]; then                  
    echo ZERO                         
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/mnt/blkmnt/run/bin
else                                                           
    echo non-ZERO                                          
fi

if [ $(./pgrep -f "synctime.sh" | wc -l) -gt 2 ]; then
    exit
fi

sleep 20
echo 0 > $dfilename1

while [ 1 ]
do
    STA0=`cat /mnt/blkmnt/run/bin/sys/NetStatus` 
    STA1=`cat /mnt/blkmnt/run/bin/sys/oNetStatus` 

    if [ $STA0 = 0 ] 
    then
        echo 0 > $dfilename1
    fi

    if [ $STA0 = 1 ] && [ $STA1 = 0 ]
    then
        sleep 400
        /mnt/blkmnt/run/bin/ntpdate -u 192.168.10.8 
        echo 1 > $dfilename1
    fi

    if [ $STA0 = 2 ] && [ $STA1 = 0 ]
    then
        sleep 400
        /mnt/blkmnt/run/bin/ntpdate -u 192.168.90.8 
        echo 2 > $dfilename1
    fi

    if [ $STA0 = 2 ] && [ $STA1 = 1 ]
    then
        sleep 10
        /mnt/blkmnt/run/bin/ntpdate -u 192.168.90.8 
        echo 2 > $dfilename1
    fi

    if [ $STA0 = 1 ] && [ $STA1 = 2 ]
    then
        sleep 10
        /mnt/blkmnt/run/bin/ntpdate -u 192.168.10.8 
        echo 1 > $dfilename1
    fi

    sleep 360

done

