#!/bin/bash

/var/mrx_apploader/lrun.sh &
/usr/sbin/ethtool -s eth0 speed 100 duplex full autoneg off

cd /var/mrx_apploader/
./cp_lib.sh &
./del_ov_log.sh 
./rmk.sh

mount /dev/mmcblk0p2 /mnt/blkmnt/

dfilename0=$"/mnt/blkmnt/run/bin/run_ipsetup.sh"
dfilename1=$"/mnt/blkmnt/run/bin/runA.sh"
dfilename2=$"/mnt/blkmnt/run/bin/mrx_aploader"

if [ -f $dfilename0 ]; then
    cd /mnt/blkmnt/run/bin
    ./run_ipsetup.sh &
else 
    ./run_ipsetup.sh &
fi

kver=`uname -r`
echo $kver
dfilename3=$"/lib/modules/"$kver
if [ -d $dfilename3 ]; then
    echo $dfilename3
else
    cp -r /lib/modules/3.0.35-2508-g54750ff $dfilename3
fi


if [ -f $dfilename1 ]; then
    cp /mnt/blkmnt/run/bin/runA.sh /var/mrx_apploader/runA.sh 
fi

if [ -f $dfilename2 ]; then
    cp /mnt/blkmnt/run/bin/mrx_aploader /var/mrx_apploader/mrx_aploader 
fi

cd /var/mrx_apploader
sync

#TEST 8
./runA.sh &
