#!/bin/bash

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/mnt/blkmnt/run/bin

pid=`echo $LD_LIBRARY_PATH | grep bin`                                      
if [ -z $pid ]; then
    echo ZERO
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/mnt/blkmnt/run/bin
else
    echo non-ZERO
fi


if [ $1 = "LOG" ]; then
    echo "LOG--> ACTION"
    pid0=`ps | grep "syslogd" | grep -v 'grep' | awk '{print $1}'`
    if [ -z $pid0 ]; then
        rm /mnt/blkmnt/log/messages.*  
        #cp /mnt/blkmnt/log/messages  /mnt/blkmnt/log/messages1
        #cp /mnt/blkmnt/log/messages1 /mnt/blkmnt/log/messages2
        #cp /mnt/blkmnt/log/messages2 /mnt/blkmnt/log/messages3
        #cp /mnt/blkmnt/log/messages3 /mnt/blkmnt/log/messages4
        #/sbin/klogd &
        #/sbin/syslogd -n -O /mnt/blkmnt/log/messages &
        #/mnt/blkmnt/run/bin/oops_restart.sh &
        #/mnt/blkmnt/run/bin/putlog.sh &
    fi
fi

pid=`ps | grep "synctime.sh" | grep -v 'grep' | awk '{print $1}'`
if [ -z $pid ]; then
    /mnt/blkmnt/run/bin/synctime.sh &  
fi

dfilename0=$"/var/mrx_apploader/sys/debugmsg"

if [ -f $dfilename0 ]; then
    echo "debug system running"
else
    echo 1 > $dfilename0
fi

chmod +x /mnt/blkmnt/run/bin/tmp/*
#cp /mnt/blkmnt/run/bin/tmp/* /var/mrx_apploader/
#cp /mnt/blkmnt/run/bin/tmp/mrx_aploader /var/mrx_apploader/mrx_aploader
#cp /mnt/blkmnt/run/bin/tmp/mrx_aploader /var/mrx_apploader/mrx_aploader_v

/mnt/blkmnt/run/bin/del_ov_log.sh
/mnt/blkmnt/run/bin/tmp/cp_lib.sh

pid=`ps | grep "traffic_checker.sh" | grep -v 'grep' | awk '{print $1}'`
if [ -z $pid ]; then
    /mnt/blkmnt/run/bin/traffic_checker.sh &
fi

pid=`ps | grep "run_ipsetup.sh" | grep -v 'grep' | awk '{print $1}'`
if [ -z $pid ]; then
    /mnt/blkmnt/run/bin/run_ipsetup.sh &
fi

HOST0="192.168.10.8"
HOST1="192.168.90.11"
COUNT=3

connection=$(cat /sys/class/net/eth0/operstate)

while [ $connection == "down" ]
do
    echo "connection down"
    connection=$(cat /sys/class/net/eth0/operstate)
    sleep 2
done

cd /mnt/blkmnt/run/bin
rm -rf *.tar.gz

count0=$(./ping -c $COUNT -w 1 $HOST0 | grep 'received' | awk -F',' '{ print $2 }' | awk '{ print $1 }')
count1=$(./ping -c $COUNT -w 1 $HOST1 | grep 'received' | awk -F',' '{ print $2 }' | awk '{ print $1 }')

if [ $count0 -eq 0 ] && [ $count1 -eq 0 ]; then
    # 100% failed 
    echo "Host : down (ping failed) at $(date)"
    chmod +x ./presender
    ./presender &
else
    echo "Host : is up ( one of them or all of them ) "
    pid=`ps | grep "putlog.sh" | grep -v 'grep' | awk '{print $1}'`
    if [ -z $pid ]; then
        /mnt/blkmnt/run/bin/putlog.sh &
    fi
fi

./del_ov_log.sh
sync

cd /mnt/blkmnt/run/bin
chmod +x ./up_apploader.sh
./up_apploader.sh &

chmod +x ./mmc3
./mmc3 writeprotect user set temp 0 24576 /dev/mmcblk0

pid=`ps | grep "mrx_bootins" | grep -v 'grep' | awk '{print $1}'`
if [ -z $pid ]; then
    ./mrx_bootins &
fi

sync


#while [ 1 ]
#cd /mnt/blkmnt/run/bin
#do
#pid=`ps | grep "mrx_bootins" | grep -v 'grep' | awk '{print $1}'`
#if [ -z $pid ]; then
#./mrx_bootins &
#fi
#
#sleep 10
#done
