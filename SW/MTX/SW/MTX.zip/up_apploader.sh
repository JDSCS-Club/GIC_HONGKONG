#!/bin/bash

sync
sleep 60

ck=`cksum /var/mtx_apploader/mtx_aploader | awk '{print $1}'`
gck=3417844673

echo "================================>"
echo "loader version : "$ck
echo "loader version : "$gck

# current version OK/FAIL
if [ $ck = $gck ]
then
    cdiff=1
else

    killall run.sh
    killall mtx_aploader

    cdiff=0
    rm /var/mtx_apploader.ptu
    sync
    dfilename0=$"/home/zeus/zip/mtx_apploader.ptu"
    dfilename1=$"/home/zeus/zip/mtx_apploader.cksum"

    if [ -f $dfilename0 ]; then
        ck=`cksum $dfilename0       | awk '{print $1}'`
        gck=`head -1 $dfilename1    | awk '{print $1}'`
    else
        ck=1
        gck=2
    fi

    if [ $ck = $gck ]
    then
        echo $dfilename0
        cp /home/zeus/zip/mtx_apploader.ptu /var/
        cd /var/
        tar xvzf  mtx_apploader.ptu
        chmod 777 /var/mtx_apploader/*
        sync
    fi
fi
echo $cdiff
