#!/bin/bash

while [ 1 ]
do
    dfilename0=$"/tmp/live"

    if [ -f $dfilename0 ]; then

        gck0=`head -1 /tmp/live | awk '{print $1}'`
        sleep 30
        gck1=`head -1 /tmp/live | awk '{print $1}'`

        if [ $gck0 = $gck1 ]
        then
            NOW=$(date +"%m-%d-%H-%M-%S")
            echo "SAME LIVE"
            echo "SAME LIVE PROCESS KILL !!!!" >> /home/zeus/log/log.txt
            echo $NOW >> /home/zeus/log/log.txt
            sync
            while [ 1 ]
            do
                killall run.sh
                killall mtx_aploader
                killall mtx_bootins
                killall mtxplayer
                killall loader
                killall hdmi-encode-streamer
                sleep 3
            done
        else
            echo "DIFF LIVE"
        fi
    fi

done
