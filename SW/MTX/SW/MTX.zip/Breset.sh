#!/bin/bash
sync
./rmk.sh
./rmk.sh
sleep 2
./crun.sh &
