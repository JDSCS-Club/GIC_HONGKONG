#!/bin/bash
sync
kill -2 `ps -ef | grep loader | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep loader | grep -v grep | awk '{print $2}'`
