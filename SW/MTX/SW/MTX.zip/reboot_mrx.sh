#!/usr/bin/expect 

proc usage {} {
    puts "usage: reboot_mrx <set ip_address> "
    exit 1
}

proc error_exit {msg} {
    puts stderr $msg
    exit $msg
}

proc do_exit {msg} {
    puts stderr $msg
    exit 2
}

set timeout 10

set argc [llength $argv]

if {$argc != 1} {
    usage 
}

set HOST_IP [lindex $argv 0]

set timeout 5
spawn ssh -o "StrictHostKeyChecking no" root@$HOST_IP
expect  "* password:" 
send "scc\r"
set timeout 1
expect  "*$" 
send "sync\r"
expect  "*$" 
send "/var/reset.sh\r"
set timeout 3
expect  "*$" 
send "reboot \n"
expect eof
