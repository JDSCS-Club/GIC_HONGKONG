#!/bin/bash
cd /mnt/blkmnt/zip
rm -rf MTX.*
wget ftp://zeus:zeus@$1/zip/MTX.zip
wget ftp://zeus:zeus@$1/zip/MTX.cksum
sync
