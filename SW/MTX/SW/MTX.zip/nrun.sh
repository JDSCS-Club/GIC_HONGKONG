#!/bin/bash

pid=`ps -ef | grep "mtx_bootins" | grep -v 'grep' | awk '{print $2}'`
if [ -z $pid ]; then
    cd /mnt/blkmnt/run/bin
    ./mtx_bootins 1 &
fi

