rm autom_player
rm server
rm mtx_bootins
rm i2cget
rm mtxbc
rm mtxshm
rm mtxplayer
rm mstchecker
rm mmtx_checker
rm nstart
rm nend
rm nend2
rm nend3
wget http://192.168.0.155/server
wget http://192.168.0.155/i2cget
wget http://192.168.0.155/mtxbc
wget http://192.168.0.155/mtxshm
wget http://192.168.0.155/autom_player
wget http://192.168.0.155/mtx_bootins
wget http://192.168.0.155/mtxplayer
wget http://192.168.0.155/mstchecker
wget http://192.168.0.155/mmtx_checker
wget http://192.168.0.155/nstart
wget http://192.168.0.155/nend2
wget http://192.168.0.155/nend3
chmod +x i2cget
chmod +x server
chmod +x mtxbc
chmod +x mtxshm
chmod +x autom_player
chmod +x mtx_bootins
chmod +x mtxplayer
chmod +x mstchecker
chmod +x mmtx_checker
chmod +x nstart
chmod +x nend
chmod +x nend2
chmod +x nend3
