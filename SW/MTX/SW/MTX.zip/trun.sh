#!/bin/bash

/etc/init.d/ntp stop
ntpdate 192.168.10.8
sleep 15
ntpdate 192.168.10.8
sleep 15
ntpdate 192.168.10.8
sleep 15
ntpdate 192.168.10.8
sleep 15
ntpdate 192.168.10.8
sleep 15
ntpdate 192.168.10.8

while [ 1 ]
    do
        ntpdate 192.168.10.8
        sleep 1h
    done
