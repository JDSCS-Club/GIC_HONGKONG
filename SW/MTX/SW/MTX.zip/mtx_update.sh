#!/bin/bash
sync
sudo cp /home/zeus/zip/MTX.zip /mnt/blkmnt/zip/
sudo cp /home/zeus/zip/MTX.cksum /mnt/blkmnt/zip/
sudo /mnt/blkmnt/run/bin/rmk.sh
sudo /mnt/blkmnt/run/bin/rmk.sh
sudo kill -9 `ps -ef | grep var/loader | grep -v grep | awk '{print $2}'`
sudo reboot
cd /var/mtx_apploader/
sudo ./mtx_aploader > /dev/null &
