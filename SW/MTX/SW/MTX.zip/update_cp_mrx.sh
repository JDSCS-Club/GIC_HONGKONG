#!/bin/bash
cd /home/zeus/zip
rm -rf ./MRX.*
wget ftp://zeus:zeus@$1/zip/MRX.zip
wget ftp://zeus:zeus@$1/zip/MRX.cksum
sync
