#!/bin/bash

# Kill process
kill -2 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
kill -2 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`

./hpdreset.sh

exit

# RESET HDMI
echo 0 > /sys/class/leds/cam_reset/brightness
sleep 1
echo 1 > /sys/class/leds/cam_reset/brightness
sleep 10

exit

cd /mnt/blkmnt/run/bin
pid=`ps -ef | grep "mtxplayer" | grep -v 'grep' | awk '{print $2}'`

# RE-PLAY
while [ -z $pid ]
do
	./mtxplayer 1 5000 224.1.1.2 15000 60 &
	sleep 5
	pid=`ps -ef | grep "mtxplayer" | grep -v 'grep' | awk '{print $2}'`
done
sleep 15

# Kill process
kill -2 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
