#!/bin/bash

dfilename0=$"/home/zeus/log/log.txt"
dfilename1=$"/home/zeus/log/log_cu.txt"
dfilename2=$"/home/zeus/log/log_pro.txt"
dfilename3=$"/home/zeus/log/voiplog.txt"

cntfilename=$"/home/zeus/log/cnt"

if [ -f $cntfilename ]; then
    echo $(cat $cntfilename)
else
    echo 0 > $cntfilename
fi


if [ -f $dfilename0 ]; then
    sz=$(ls -l $dfilename0 | awk '{print $5}')
    echo $dfilename0 - $sz
while [ $sz -gt 5000000 ];
do
        sz=$(ls -l $dfilename0 | awk '{print $5}')
        echo $dfilename0 - $sz
		sed -e '1,24500d'  $dfilename0 > back.log
		cp back.log $dfilename0
		rm back.log
		sync
done
fi


if [ -f $dfilename1 ]; then
    sz=$(ls -l $dfilename1 | awk '{print $5}')
    echo $dfilename1 - $sz
while [ $sz -gt 3000000 ];
do
        sz=$(ls -l $dfilename1 | awk '{print $5}')
        echo $dfilename1 - $sz
		sed -e '1,24500d'  $dfilename1 > back.log
		cp back.log $dfilename1
		rm back.log
		sync
done
fi

if [ -f $dfilename2 ]; then

    sz=$(ls -l $dfilename2 | awk '{print $5}')
    echo $dfilename2 - $sz

while [ $sz -gt 5000000 ];
do
        sz=$(ls -l $dfilename2 | awk '{print $5}')
        echo $dfilename2 - $sz
		sed -e '1,24500d'  $dfilename2 > back.log
		cp back.log $dfilename2
		rm back.log
		sync
done
fi


if [ -f $dfilename3 ]; then
    sz=$(ls -l $dfilename3 | awk '{print $5}')
    echo $dfilename3 - $sz
    while [ $sz -gt 5000000 ];
    do
        sz=$(ls -l $dfilename3 | awk '{print $5}')
        echo $dfilename3 - $sz
		sed -e '1,24500d'  $dfilename3 > back.log
		cp back.log $dfilename3
		rm back.log
		sync
    done
fi




