#!/bin/bash

dfilename0=$"/mnt/blkmnt/run/bin/sys/traffic_val0"
dfilename1=$"/mnt/blkmnt/run/bin/sys/traffic_val1"

cd /mnt/blkmnt/run/bin

echo 1  > $dfilename1
echo 10 > $dfilename0

while [ 1 ]
do

    val1=`/mnt/blkmnt/run/bin/vnstat -tr | grep "tx" | awk '{print $3}'`
    val0=`/mnt/blkmnt/run/bin/vnstat -tr | grep "tx" | awk '{print $2}'`

    echo $val0 > $dfilename0

    if [ $val1 == "kbit/s" ]; then
        echo 0 > $dfilename1
    else
        echo 1 > $dfilename1
    fi

done
