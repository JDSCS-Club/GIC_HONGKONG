#!/bin/bash
cd /mnt/blkmnt/zip
cp /home/zeus/zip/MTX.zip .
cp /home/zeus/zip/MTX.cksum .
unzip -o /home/zeus/zip/MTX.zip -d /mnt/blkmnt/run/bin
sync
cd /mnt/blkmnt/run/bin
./mrun.sh 
./crun.sh &
