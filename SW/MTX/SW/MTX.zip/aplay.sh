#!/bin/bash

killall gplay
killall aplay
killall gst-play-1.0

fullpath=$1
dirname=$(dirname $fullpath)
basename=$(basename  $fullpath)
filename=${basename%.*}
fileext=${basename#*.}
echo $fileext

gst-play-1.0 $1 > /dev/null

exit

