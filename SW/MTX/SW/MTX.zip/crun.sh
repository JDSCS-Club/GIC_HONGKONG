#!/bin/bash

#
# network setting fixed
#

/sbin/mii-tool -F 100baseTx-FD eth0
sleep 1


#
# volume setting
#

amixer -c 0 set PCM 75%
amixer -c 0 set 'Headphone' 122

#
# logdel
#

/mnt/blkmnt/run/bin/del_ov_log.sh


#
# file initial
#

#chmod +x /mnt/blkmnt/run/bin/tmp/*
#cp /mnt/blkmnt/run/bin/tmp/* /var/mrx_apploader/

echo 1 > /mnt/blkmnt/run/bin/sys/nvr_command
echo 0 > /mnt/blkmnt/run/sys/ping_report
echo 0 > /mnt/blkmnt/run/bin/sys/CliStatus
chmod 0644 /etc/logrotate.conf

chown -R zeus:zeus  /mnt/blkmnt/zeus
chown -R wav:wav    /mnt/blkmnt/wav
chown -R zeus:zeus  /home/zeus
chown -R wav:wav    /home/wav

echo 1 > ./sys/enable0
echo 1 > ./sys/enable1
echo 1 > ./sys/enable2
echo 1 > ./sys/enable3

#
# hdmi checker
#

cd /mnt/blkmnt/run/bin

#./i2cset -f 1 0x48 0x50 0x13 b
#./hpdreset.sh
#sleep 2

#get=`/mnt/blkmnt/run/bin/i2cget -f 1 0x48 0xa b | head -1`
#if [ $get == 17 ]; then
    #echo startup_hdmierr > /home/zeus/log/hdmisetval
    #echo 0 > /sys/class/leds/cam-reset/brightness
    #sleep 1
    #echo 1 > /sys/class/leds/cam-reset/brightness

    #./mtxplayer 1 5000 224.1.1.2 15000 60 &

    #sleep 18
    #kill -2 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
    #kill -2 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
    #kill -2 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
    #kill -2 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
    #kill -2 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
#fi

#
# updaload application
#

pid=`ps -ef | grep "voip_logmaker" | grep -v 'grep' | awk '{print $2}'`
if [ -z $pid ]; then
     ./voip_logmaker > /dev/null &
fi

#process checker
#./procheck.sh &

#bulk tester
./bulk.sh &

#./up_apploader.sh &
#pid=`ps -ef | grep "mtx_bootins" | grep -v 'grep' | awk '{print $2}'`
#if [ -z $pid ]; then
    #killall mtx_bootins
    #kill -2 `ps -ef | grep mtx_bootins | grep -v grep | awk '{print $2}'`
    #kill -9 `ps -ef | grep mtx_bootins | grep -v grep | awk '{print $2}'`
#fi

#while [ 1 ]
#cd /mnt/blkmnt/run/bin
   #do
        #pid=`ps -ef | grep "mtx_bootins" | grep -v 'grep' | awk '{print $2}'`
        #if [ -z $pid ]; then
                #./mtx_bootins 1 &
        #fi
        #sleep 1
#done

while [ 1 ]
cd /mnt/blkmnt/run/bin
do
    ./mtx_bootins 1 > /dev/null
    sleep 0.3
done
