#!/bin/bash
sed -e '1,100d' /home/zeus/log/log_pro.txt > /mnt/blkmnt/log/log1.log
mv /mnt/blkmnt/log/log1.log /home/zeus/log/log_pro.txt
sync
