#!/usr/bin/expect 

proc usage {} {
    puts "usage: update_mrx.sh <set ip_address> <ftp address>"
    exit 1
}

proc error_exit {msg} {
    puts stderr $msg
    exit $msg
}

proc do_exit {msg} {
    puts stderr $msg
    exit 2
}

set timeout 10

set argc [llength $argv]

if {$argc != 2} {
    usage 
}

set HOST_IP [lindex $argv 0]
set FTP_IP [lindex $argv 1]

set timeout 5
spawn ssh -o "StrictHostKeyChecking no" root@$HOST_IP
expect  "* password:" 
send "scc\r"
set timeout 1
expect  "*$" 
send "sed -e s/0.155/10.8/g /var/mrx_apploader/list > test.txt.tmp\r"
expect  "*$" 
send "mv test.txt.tmp /var/mrx_apploader/list\r"

expect  "*$" 
send "cd /mnt/blkmnt/zip\r"
expect  "*$" 
send "rm -rf *\r"

set timeout 5
#sprintf(msg, "wget ftp://%s:%s@%s/%s", ID, PW, SIP, FN);
expect  "*$" 
send "wget ftp://zeus:zeus@$FTP_IP/zip/MRX.zip\r"
expect  "*$" 
send "wget ftp://zeus:zeus@$FTP_IP/zip/MRX.cksum\r"

set timeout 1
expect  "*$" 
send "sync\r"
expect  "*$" 
send "/var/reset.sh\r"
set timeout 3
expect  "*$" 
send "reboot \n"
expect eof
