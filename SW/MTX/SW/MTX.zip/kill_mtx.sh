#!/bin/bash

kill -9 `ps -ef | grep run.sh | grep -v grep | awk '{print $2}'`
kill -2 `ps -ef | grep mtx_aploader | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep mtx_aploader | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep nrun.sh | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep crun.sh | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep mtx_aploader | grep -v grep | awk '{print $2}'`
kill -2 `ps -ef | grep mtx_bootins | grep -v grep | awk '{print $2}'`
sleep 1
kill -9 `ps -ef | grep mtx_bootins | grep -v grep | awk '{print $2}'`
kill -2 `ps -ef | grep server | grep -v grep | awk '{print $2}'`
sleep 1
kill -9 `ps -ef | grep server | grep -v grep | awk '{print $2}'`
kill -2 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
sleep 1
kill -9 `ps -ef | grep mtxplayer | grep -v grep | awk '{print $2}'`
kill -2 `ps -ef | grep mtxbc | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep mtxbc | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep mtx6  | grep -v grep | awk '{print $2}'`
kill -2 `ps -ef | grep mtxshm | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep sender | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep server | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep caplisten | grep -v grep | awk '{print $2}'`
kill -2 `ps -ef | grep mstchecker | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep mstchecker | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep mmtx_checker | grep -v grep | awk '{print $2}'`
kill -2 `ps -ef | grep mtx_bootins | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep mtx_bootins | grep -v grep | awk '{print $2}'`
kill -2 `ps -ef | grep hdmi-encode-streamer | grep -v grep | awk '{print $2}'`
kill -9 `ps -ef | grep hdmi-encode-streamer | grep -v grep | awk '{print $2}'`
